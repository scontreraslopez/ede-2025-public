package io.github.scontreraslopez;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import static org.junit.jupiter.api.Assertions.*;


/**
 *
 *
 * | Método | Entrada | Resultado esperado |
 * |--------|---------|-------------------|
 * | `kmAMillas` | `1.0` | `0.6214` (±0.0001) |
 * | `kmAMillas` | `25.0` | `15.5343` (±0.0001) |
 * | `kmAMillas` | `50.0` | `31.0686` (±0.0001) |
 * | `kmAMillas` | `100.0` | `62.1371` (±0.0001) |
 * | `millasAKm` | `1.0` | `1.6093` (±0.0001) |
 * | `millasAKm` | `5.0` | `8.0467` (±0.0001) |
 * | `millasAKm` | `10.0` | `16.0934` (±0.0001) |
 * | `millasAKm` | `20.0` | `32.1869` (±0.0001) |
 * | `celsiusAFahrenheit` | `-40.0` | `-40.0` |
 * | `celsiusAFahrenheit` | `0.0` | `32.0` |
 * | `celsiusAFahrenheit` | `20.0` | `68.0` |
 * | `celsiusAFahrenheit` | `37.0` | `98.6` |
 * | `celsiusAFahrenheit` | `100.0` | `212.0` |
 *
 *
 *
 */

class ConversorUnidadesTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void kmAMillas() {
    }

    @Test
    void millasAKm() {
    }

    @Test
    void celsiusAFahrenheit() {
    }

    @ParameterizedTest
    void esNegativo() {
    }
}